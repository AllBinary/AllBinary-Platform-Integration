/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.j2se;

import javax.microedition.lcdui.Image;

/**
 *
 * @author User
 */
public class PostLoadPlatformImmutableImage extends PostLoadJ2SEPlatformImage {

    private static final PostLoadPlatformImmutableImage instance = new PostLoadPlatformImmutableImage();

    /**
     * @return the instance
     */
    public static PostLoadPlatformImmutableImage getInstance() {
        return instance;
    }

    @Override
    public int getWidth(final Image image, final int width) {
        //LogUtil.put(LogFactory.getInstance("image.getWidth2()" + image.getWidth2(), this, "image.getWidth2()"));
        return image.getWidth2();
    }
    
    @Override
    public int getHeight(final Image image, final int height) {
        //LogUtil.put(LogFactory.getInstance("image.getHeight2()" + image.getHeight2(), this, "image.getHeight2()"));
        return image.getHeight2();
    }

    @Override
    public void getRGB(final int[] argb, final int offset, final int scanlength, final int x, final int y, final int width, final int height, final Image image) {
    
        image.getRGB2(argb, offset, scanlength, x, y, width, height);

    }
    
}
