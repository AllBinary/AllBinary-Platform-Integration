/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.platform;

import javax.microedition.lcdui.Graphics;
import org.microemu.device.j2se.J2SEDisplayGraphics;
import org.microemu.device.j2se.J2SEGraphicsSurface;

/**
 *
 * @author User
 */
public class DisplayGraphicsFactory {
    
    public static Graphics getInstance(Object repaintObject) {
        return new J2SEDisplayGraphics((J2SEGraphicsSurface) repaintObject);
    }
}
