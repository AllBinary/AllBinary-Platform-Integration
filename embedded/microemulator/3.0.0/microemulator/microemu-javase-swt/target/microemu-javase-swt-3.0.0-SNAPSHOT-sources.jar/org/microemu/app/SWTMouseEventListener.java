/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.app;

import javax.microedition.midlet.MIDlet;
import org.eclipse.swt.events.DragDetectEvent;
import org.eclipse.swt.events.MouseEvent;

/**
 *
 * @author User
 */
public class SWTMouseEventListener {
    
    public void mouseDoubleClick(final MIDlet midlet, final MouseEvent mouseEvent) {
        
    }

    public void mouseDown(final MIDlet midlet, final MouseEvent mouseEvent) {

        midlet.mousePressed(mouseEvent.x, mouseEvent.y, mouseEvent.button);

    }

    public void mouseUp(final MIDlet midlet, final MouseEvent mouseEvent) {
        
        midlet.mouseReleased(mouseEvent.x, mouseEvent.y, mouseEvent.button);
        
    }
    
    public void mouseMove(final MIDlet midlet, final MouseEvent mouseEvent) {

        midlet.mouseMoved(mouseEvent.x, mouseEvent.y, mouseEvent.button);
        
    }

    public void dragDetected(final MIDlet midlet, final DragDetectEvent mouseEvent) {

        midlet.mouseDragged(mouseEvent.x, mouseEvent.y, mouseEvent.button);
        
    }    
    
}
