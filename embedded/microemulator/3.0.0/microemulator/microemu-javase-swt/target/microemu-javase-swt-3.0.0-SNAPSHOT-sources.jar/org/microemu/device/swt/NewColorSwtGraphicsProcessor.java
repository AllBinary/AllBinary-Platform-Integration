/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.swt;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGBA;
import org.microemu.app.ui.swt.SwtGraphics;

/**
 *
 * @author User
 */
public class NewColorSwtGraphicsProcessor extends SwtGraphicsProcessor {
    
    private final SwtDeviceDisplay swtDeviceDisplay;
    
    public NewColorSwtGraphicsProcessor(final SwtDeviceDisplay swtDeviceDisplay) {
        this.swtDeviceDisplay = swtDeviceDisplay;
    }
    
    public Color getColor(final SwtGraphics g, final RGBA rgba) {
        final Color color = g.getColor(rgba);
        swtDeviceDisplay.foregroundGraphicsProcessor = new ExistingColorSwtGraphicsProcessor(color);
        return color;
    }

}
