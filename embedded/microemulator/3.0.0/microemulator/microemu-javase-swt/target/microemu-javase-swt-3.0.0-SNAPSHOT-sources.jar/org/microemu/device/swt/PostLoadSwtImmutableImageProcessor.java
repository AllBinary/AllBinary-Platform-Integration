/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.swt;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.PostLoadImageProcessor;

import org.eclipse.swt.graphics.ImageData;
import org.microemu.app.ui.swt.SwtDeviceComponent;

/**
 *
 * @author User
 */
public class PostLoadSwtImmutableImageProcessor extends PostLoadImageProcessor {
    
    private final SwtImmutableImage originalImmutableImage;
    
    public PostLoadSwtImmutableImageProcessor(final SwtImmutableImage originalImmutableImage) {
        this.originalImmutableImage = originalImmutableImage;
    }
    
    public void process(final Image image) {
        
        final int width = originalImmutableImage.getWidth();
        final int height = originalImmutableImage.getHeight();
        final ImageData imageData = originalImmutableImage.image.getImageData().scaledTo(width, height);
        ((SwtImmutableImage) image).init(SwtDeviceComponent.createImage(imageData));
        
    }
    
}
