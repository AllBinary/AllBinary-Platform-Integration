/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.swt;

/**
 *
 * @author User
 */
public class RepaintProcessor {
 
    private static final RepaintProcessor instance = new RepaintProcessor();

    /**
     * @return the instance
     */
    public static RepaintProcessor getInstance() {
        return instance;
    }
    
    public void repaint(final Object context, final int x, final int y, final int width, final int height) {
        
    }
    
}
