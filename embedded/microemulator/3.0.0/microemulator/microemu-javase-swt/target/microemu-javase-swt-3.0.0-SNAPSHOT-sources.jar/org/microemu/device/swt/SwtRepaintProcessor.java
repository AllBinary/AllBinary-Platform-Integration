/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package org.microemu.device.swt;

import org.microemu.device.EmulatorContext;

/**
 *
 * @author User
 */
public class SwtRepaintProcessor extends RepaintProcessor {
    
    private static final SwtRepaintProcessor instance = new SwtRepaintProcessor();

    /**
     * @return the instance
     */
    public static SwtRepaintProcessor getInstance() {
        return instance;
    }
    
    public void repaint(final Object context, final int x, final int y, final int width, final int height) {
        ((EmulatorContext) context).getDisplayComponent().repaintRequest(x, y, width, height);
    }
    
}
