/**
 *  MicroEmulator
 *  Copyright (C) 2008 Bartek Teodorczyk <barteo@barteo.net>
 *
 *  It is licensed under the following two licenses as alternatives:
 *    1. GNU Lesser General Public License (the "LGPL") version 2.1 or any newer version
 *    2. Apache License (the "AL") Version 2.0
 *
 *  You may not use this file except in compliance with at least one of
 *  the above two licenses.
 *
 *  You may obtain a copy of the LGPL at
 *      http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt
 *
 *  You may obtain a copy of the AL at
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the LGPL or the AL for the specific language governing permissions and
 *  limitations.
 *
 *  @version $Id: SwtTextBoxUI.java 2400 2010-07-04 15:45:12Z r.c.g@gmx.de $
 */

package org.microemu.device.swt.ui;

import javax.microedition.lcdui.TextBox;

import org.microemu.device.impl.ui.DisplayableImplUI;
import org.microemu.device.ui.TextBoxUI;

public class SwtTextBoxUI extends DisplayableImplUI implements TextBoxUI {

	public SwtTextBoxUI(TextBox textBox) {
		super(textBox);
	}

	public int getCaretPosition() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getString() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setString(String text) {
		// TODO Auto-generated method stub

	}

	@Override
	public void insert(String text, int position) {
		// TODO Auto-generated method stub
		
	}

        public void delete(int offset, int length) {
            
        }
}
