/*
 * AllBinary Open License Version 1
 * Copyright (c) 2022 AllBinary
 * 
 * By agreeing to this license you and any business entity you represent are
 * legally bound to the AllBinary Open License Version 1 legal agreement.
 * 
 * You may obtain the AllBinary Open License Version 1 legal agreement from
 * AllBinary or the root directory of AllBinary's AllBinary Platform repository.
 * 
 * Created By: Travis Berthelot
 * 
 */
package javax.microedition.lcdui;

/**
 *
 * @author User
 */
public class OpenGLESPostLoadPlatformImage extends PlatformImage {

    private static final OpenGLESPostLoadPlatformImage instance = new OpenGLESPostLoadPlatformImage();

    /**
     * @return the instance
     */
    public static OpenGLESPostLoadPlatformImage getInstance() {
        return instance;
    }
    
    @Override
    public Object getImage(final Object graphicsSurface2) {
        throw new RuntimeException();
    }
    
    @Override
    public int getWidth(final Object graphicsSurface2, final int width) {
        throw new RuntimeException();
    }

    @Override
    public int getHeight(final Object graphicsSurface2, final int height) {
        throw new RuntimeException();
    }
    
    @Override
    public int getWidth(final Image image, final int width) {
        throw new RuntimeException();
    }

    @Override
    public int getHeight(final Image image, final int height) {
        throw new RuntimeException();
    }
    
    @Override
    public void drawImage(final Image image, final int x, final int y, int anchor, final javax.microedition.lcdui.Graphics g2, final Object g) {
        // LogUtil.put(LogFactory.getInstance(CommonStrings.getInstance().START, this, "drawImage"));
        g2.drawImage(image, x, y, anchor);
    }

    @Override
    public void drawRegion(final Image image, final int x_src, final int y_src, final int width,
            final int height, final int transform, final int x_dst, final int y_dst, final int anchor, final javax.microedition.lcdui.Graphics g)
    {
        g.drawRegion(image, x_src, y_src, width, height, transform, x_dst, y_dst, anchor);
    }

    @Override
    public void getRGB(final int[] argb, final int offset, final int scanlength, final int x, final int y, final int width, final int height, final Image image) {
    
        throw new RuntimeException();
    }
    
}
