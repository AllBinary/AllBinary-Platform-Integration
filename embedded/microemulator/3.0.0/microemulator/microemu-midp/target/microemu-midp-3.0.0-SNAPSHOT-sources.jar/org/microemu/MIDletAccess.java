/*
 *  MicroEmulator
 *  Copyright (C) 2001 Bartek Teodorczyk <barteo@barteo.net>
 *
 *  It is licensed under the following two licenses as alternatives:
 *    1. GNU Lesser General Public License (the "LGPL") version 2.1 or any newer version
 *    2. Apache License (the "AL") Version 2.0
 *
 *  You may not use this file except in compliance with at least one of
 *  the above two licenses.
 *
 *  You may obtain a copy of the LGPL at
 *      http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt
 *
 *  You may obtain a copy of the AL at
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the LGPL or the AL for the specific language governing permissions and
 *  limitations.
 *  
 *  Contributor(s):
 *    Andres Navarro
 *    
 *  @version $Id: MIDletAccess.java 1972 2009-03-12 13:54:22Z barteo $    
 */

package org.microemu;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import org.microemu.DisplayAccess;

/**
 * 
 * Enables access to MIDlet protected methods.
 *
 */
public class MIDletAccess {
	
	public MIDlet midlet;

	private DisplayAccess displayAccess;

	public MIDletAccess(MIDlet amidlet) {
		midlet = amidlet;
	}

	public DisplayAccess getDisplayAccess() {
		return displayAccess;
	}

	public void setDisplayAccess(DisplayAccess adisplayAccess) {
		displayAccess = adisplayAccess;
	}

	public void startApp() throws MIDletStateChangeException {
            
        }

	public void pauseApp() {
            
        }

	public void destroyApp(boolean unconditional) throws MIDletStateChangeException {
            
        }

}